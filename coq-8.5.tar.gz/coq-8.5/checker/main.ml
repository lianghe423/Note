
let _ = Checker.start ()
